library(testthat)
library(idpedu)

test_check("idpedu")


