# Clean artifacts directory once per test session
prepare_artifacts_dir()



