This file mirrors `dev/CHANGESET.md` for now and will be updated during Task 2 to list legacy removals/deprecations in detail.

See `dev/CHANGESET.md`.



